package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

@RestController
class ServerController{
    // Map hashed name to /hash

	// method for determining request response, created with help from site https://www.baeldung.com/spring-response-entity
	@GetMapping("/hash")
	public ResponseEntity<String> getName(@RequestParam(name = "personName", required = false, defaultValue = "Danielle Eeg") String personName) throws NoSuchAlgorithmException {

		// if the personName does not pass the validation test
	    if (!isValidInput(personName)) {
	    	// set response message
	        return ResponseEntity.badRequest().body("Invalid personName. Please provide a valid name that is less than 25 characters and only contains alphabetical characters, spaces, and/or hyphens.");
	    }

	    // if the name passes validation, return the hash output of personName
	    return ResponseEntity.ok(myHash(personName));
	}
	
	// private method for validating input string
	private boolean isValidInput(String personName) {
		
		//if the input is greater than 25 characters, return false
	    if (personName.length() > 25) {
	        return false;
	    }

	    // Regular expression used to ensure input only contains alphabetical characters, spaces, and/or dashes
	    return personName.matches("^[a-zA-Z\\- ]+$");
	}

    // Hash function returns SHA-256 hash value for string input
    // Using method from source: https://www.tutorialspoint.com/java_cryptography/java_cryptography_message_digest.htm
    public String myHash(String data) throws NoSuchAlgorithmException{
  	  
        //Creating the MessageDigest object  
        MessageDigest md = MessageDigest.getInstance("SHA-256");

        //Passing data to the created MessageDigest Object
        md.update(data.getBytes());
        
        //Compute the message digest
        byte[] digest = md.digest();      
        System.out.println(digest);  
       
        //Converting the byte array in to HexString format
        StringBuffer hexString = new StringBuffer();
        
        // Convert byte by byte and append to string
        for (int i = 0;i<digest.length;i++) {
           hexString.append(Integer.toHexString(0xFF & digest[i]));
        }
        
        // Format output        
        String returnString = "<p><b>Data: </b>"+ data+ "</p>\n"
        		+ "<p></p>\n"
        		+ "<p><b>Name of Cipher Algorithm Used:</b> SHA-256</p>\n"
        		+ "<p></p>\n"
        		+ "<p><b>Checksum Value:</b> " + hexString.toString()+ "</p>";
        return returnString; 
    }
}
